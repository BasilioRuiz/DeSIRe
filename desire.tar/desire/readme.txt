_____________________________________________________________________________

   DeSIRe project

   Authors: Basilio Ruiz Cobo, Han Uitenbroek, David Orozco, Carlos Quintero
   Contact: brc@iac.es
   Date   : 09 September 2019

-----------------------------------------------------------------------------

See "doc/installation.txt" for details.

1) DIRECTORIES
   bin   : executables
   doc   : documentation
   idl   : usefull IDL procedures
   run   : working directory
   src   : source code
   var   : application data files

2) INSTALLATION
   src>  make [fc=gfortran] install

3) EXECUTION
   run/example>  ../../bin/desire <control file>

_____________________________________________________________________________
